// Aqui você pode adicionar interatividade adicional, se necessário
document.addEventListener('DOMContentLoaded', () => {
    const gameIframe = document.getElementById('gameIframe');

    // Caso queira adicionar algum comportamento interativo, como maximizar/minimizar
    // Exemplo: Maximizar o jogo
    gameIframe.style.height = "600px";
    gameIframe.style.width = "800px";
});
